const getPagination = (query) => {
  const page = Math.max(Number(query.page) || 1, 1);
  const limit = Math.min(Math.max(Number(query.limit) || 10, 1), 100);
  const skip = (page - 1) * limit;

  return { page, limit, skip };
};

const buildPaginationMeta = ({ total, page, limit }) => ({
  total,
  page,
  limit,
  totalPages: Math.ceil(total / limit) || 1,
  hasNextPage: page * limit < total,
  hasPrevPage: page > 1,
});

const buildSearchFilter = (search, fields = []) => {
  if (!search) {
    return {};
  }

  const safeSearch = search.trim();

  if (!safeSearch) {
    return {};
  }

  return {
    $or: fields.map((field) => ({
      [field]: { $regex: safeSearch, $options: "i" },
    })),
  };
};

module.exports = {
  buildPaginationMeta,
  buildSearchFilter,
  getPagination,
};
