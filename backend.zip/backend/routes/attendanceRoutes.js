const express = require("express");

const { checkIn, checkOut, getMyAttendance } = require("../controllers/attendanceController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/checkin", protect, checkIn);
router.post("/checkout", protect, checkOut);
router.get("/me", protect, getMyAttendance);

module.exports = router;
