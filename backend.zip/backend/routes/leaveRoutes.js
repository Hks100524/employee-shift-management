const express = require("express");

const { applyLeave, approveLeave, getLeaves, rejectLeave } = require("../controllers/leaveController");
const { protect } = require("../middleware/authMiddleware");
const authorize = require("../middleware/roleMiddleware");

const router = express.Router();

router
  .route("/")
  .get(protect, authorize("admin", "manager", "employee"), getLeaves)
  .post(protect, authorize("admin", "manager", "employee"), applyLeave);

router.put("/:id/approve", protect, authorize("admin", "manager"), approveLeave);
router.put("/:id/reject", protect, authorize("admin", "manager"), rejectLeave);

module.exports = router;
