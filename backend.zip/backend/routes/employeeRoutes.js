const express = require("express");

const {
  createEmployee,
  deleteEmployee,
  getEmployees,
  updateEmployee,
} = require("../controllers/employeeController");
const { protect } = require("../middleware/authMiddleware");
const authorize = require("../middleware/roleMiddleware");

const router = express.Router();

router
  .route("/")
  .get(protect, authorize("admin", "manager"), getEmployees)
  .post(protect, authorize("admin", "manager"), createEmployee);

router
  .route("/:id")
  .put(protect, authorize("admin", "manager"), updateEmployee)
  .delete(protect, authorize("admin"), deleteEmployee);

module.exports = router;
