const express = require("express");

const { createShift, deleteShift, getShifts, updateShift } = require("../controllers/shiftController");
const { protect } = require("../middleware/authMiddleware");
const authorize = require("../middleware/roleMiddleware");

const router = express.Router();

router
  .route("/")
  .get(protect, authorize("admin", "manager", "employee"), getShifts)
  .post(protect, authorize("admin", "manager"), createShift);

router
  .route("/:id")
  .put(protect, authorize("admin", "manager"), updateShift)
  .delete(protect, authorize("admin", "manager"), deleteShift);

module.exports = router;
