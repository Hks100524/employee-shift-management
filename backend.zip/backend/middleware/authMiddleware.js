const jwt = require("jsonwebtoken");

const User = require("../models/User");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");

const protect = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) {
    throw new AppError("Not authorized. Missing bearer token.", 401);
  }

  const token = header.split(" ")[1];
  const decoded = jwt.verify(token, process.env.JWT_SECRET);

  const user = await User.findById(decoded.id)
    .select("-password")
    .populate("employee");

  if (!user) {
    throw new AppError("User not found.", 401);
  }

  if (!user.isActive) {
    throw new AppError("User account is inactive.", 403);
  }

  req.user = user;
  next();
});

module.exports = {
  protect,
};
