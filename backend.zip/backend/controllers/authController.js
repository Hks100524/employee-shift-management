const Employee = require("../models/Employee");
const User = require("../models/User");
const createAuditLog = require("../utils/auditLogger");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const { normalizeDateInput } = require("../utils/dateTime");
const generateToken = require("../utils/generateToken");
const { normalizeEmail, optionalString, requiredString } = require("../utils/validation");

const ALLOWED_ROLES = ["admin", "manager", "employee"];

const sanitizeUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  isActive: user.isActive,
  employee: user.employee || null,
  lastLoginAt: user.lastLoginAt,
  createdAt: user.createdAt,
});

const register = asyncHandler(async (req, res) => {
  const name = requiredString(req.body.name, "name");
  const email = normalizeEmail(req.body.email);
  const password = requiredString(req.body.password, "password");

  if (password.length < 6) {
    throw new AppError("Password must be at least 6 characters long.", 400);
  }

  const requestedRole = ALLOWED_ROLES.includes(String(req.body.role || "").toLowerCase())
    ? String(req.body.role).toLowerCase()
    : "employee";

  const existingUsersCount = await User.countDocuments();
  const role = existingUsersCount === 0 ? requestedRole : "employee";

  const existingUser = await User.findOne({ email });
  const existingEmployee = await Employee.findOne({ email });

  if (existingUser || existingEmployee) {
    throw new AppError("An account with this email already exists.", 409);
  }

  const joining = normalizeDateInput(
    req.body.joining_date || req.body.joiningDate || new Date(),
    "joining_date"
  );

  const employee = await Employee.create({
    name,
    email,
    department: optionalString(req.body.department) || "General",
    branch: optionalString(req.body.branch) || "Head Office",
    designation:
      optionalString(req.body.designation) ||
      (role === "admin" ? "Administrator" : role === "manager" ? "Manager" : "Employee"),
    joiningDate: joining.date,
    status: "active",
    createdBy: null,
  });

  let user;

  try {
    user = await User.create({
      name,
      email,
      password,
      role,
      employee: employee._id,
      isActive: true,
    });
  } catch (error) {
    await Employee.findByIdAndDelete(employee._id);
    throw error;
  }

  employee.user = user._id;
  await employee.save();

  const hydratedUser = await User.findById(user._id)
    .select("-password")
    .populate("employee");

  await createAuditLog(req, {
    action: "auth.register",
    entityType: "User",
    entityId: user._id,
    metadata: { role: user.role },
  });

  res.status(201).json({
    success: true,
    message: "Registration successful.",
    token: generateToken(hydratedUser),
    data: sanitizeUser(hydratedUser),
  });
});

const login = asyncHandler(async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const password = requiredString(req.body.password, "password");

  const user = await User.findOne({ email })
    .select("+password")
    .populate("employee");

  if (!user) {
    throw new AppError("Invalid email or password.", 401);
  }

  const isPasswordValid = await user.matchPassword(password);

  if (!isPasswordValid) {
    throw new AppError("Invalid email or password.", 401);
  }

  if (!user.isActive || (user.employee && user.employee.status === "inactive")) {
    throw new AppError("Your account is inactive. Please contact an administrator.", 403);
  }

  user.lastLoginAt = new Date();
  await user.save({ validateBeforeSave: false });

  await createAuditLog(req, {
    action: "auth.login",
    entityType: "User",
    entityId: user._id,
    metadata: { role: user.role },
  });

  res.json({
    success: true,
    message: "Login successful.",
    token: generateToken(user),
    data: sanitizeUser(user),
  });
});

const getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)
    .select("-password")
    .populate({
      path: "employee",
      populate: {
        path: "manager",
        select: "name email designation",
      },
    });

  res.json({
    success: true,
    data: sanitizeUser(user),
  });
});

const logout = asyncHandler(async (req, res) => {
  await createAuditLog(req, {
    action: "auth.logout",
    entityType: "User",
    entityId: req.user._id,
    metadata: { role: req.user.role },
  });

  res.json({
    success: true,
    message: "Logout successful.",
  });
});

module.exports = {
  getMe,
  login,
  logout,
  register,
};
