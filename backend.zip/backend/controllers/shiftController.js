const Employee = require("../models/Employee");
const Leave = require("../models/Leave");
const Shift = require("../models/Shift");
const Attendance = require("../models/Attendance");
const ShiftAssignmentLock = require("../models/ShiftAssignmentLock");
const createAuditLog = require("../utils/auditLogger");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const {
  buildRequestCacheKey,
  getCachedPayload,
  invalidateCacheNamespace,
  setCachedPayload,
} = require("../utils/cacheStore");
const { getShiftWindow, normalizeDateInput } = require("../utils/dateTime");
const { buildPaginationMeta, getPagination } = require("../utils/queryFeatures");

const getRequesterEmployeeId = (req) =>
  String(req.user.employee?._id || req.user.employee || "");

const getManagerEmployeeIds = async (req) => {
  if (req.user.role !== "manager") {
    return null;
  }

  const requesterEmployeeId = getRequesterEmployeeId(req);

  if (!requesterEmployeeId) {
    throw new AppError("Manager profile is not linked to an employee record.", 403);
  }

  const employees = await Employee.find({ manager: requesterEmployeeId }).select("_id").lean();
  return employees.map((item) => String(item._id));
};

const assertManagerCanAssign = async (req, employeeId) => {
  if (req.user.role !== "manager") {
    return;
  }

  const requesterEmployeeId = getRequesterEmployeeId(req);
  const employee = await Employee.findById(employeeId).select("manager");

  if (!employee || String(employee.manager || "") !== requesterEmployeeId) {
    throw new AppError("Managers can only manage shifts for their direct reports.", 403);
  }
};

const ensureEmployeeCanBeAssigned = async (employeeId) => {
  const employee = await Employee.findById(employeeId);

  if (!employee) {
    throw new AppError("Employee not found.", 404);
  }

  if (employee.status !== "active") {
    throw new AppError("Inactive employees cannot be assigned shifts.", 400);
  }

  return employee;
};

const ensureNoOverlap = async ({ employeeId, shiftDateKey, startMinutes, endMinutes, excludeId }) => {
  const overlappingShift = await Shift.findOne({
    employee: employeeId,
    shiftDateKey,
    status: { $ne: "cancelled" },
    ...(excludeId ? { _id: { $ne: excludeId } } : {}),
    startMinutes: { $lt: endMinutes },
    endMinutes: { $gt: startMinutes },
  });

  if (overlappingShift) {
    throw new AppError("Shift overlaps with an existing assignment.", 409);
  }
};

const ensureNoApprovedLeaveConflict = async (employeeId, shiftDate) => {
  const approvedLeave = await Leave.findOne({
    employee: employeeId,
    status: "approved",
    startDate: { $lte: shiftDate },
    endDate: { $gte: shiftDate },
  });

  if (approvedLeave) {
    throw new AppError("Cannot assign a shift on an approved leave date.", 409);
  }
};

const createShiftLockRecord = (employeeId, shiftDateKey) =>
  ShiftAssignmentLock.create({
    employee: employeeId,
    shiftDateKey,
    expiresAt: new Date(Date.now() + 15000),
  });

const acquireShiftLock = async (employeeId, shiftDateKey) => {
  try {
    return await createShiftLockRecord(employeeId, shiftDateKey);
  } catch (error) {
    if (error.code !== 11000) {
      throw error;
    }

    await ShiftAssignmentLock.deleteMany({
      employee: employeeId,
      shiftDateKey,
      expiresAt: { $lt: new Date() },
    });

    try {
      return await createShiftLockRecord(employeeId, shiftDateKey);
    } catch (retryError) {
      if (retryError.code === 11000) {
        throw new AppError(
          "Another shift update is already being processed for this employee on the selected date.",
          409
        );
      }

      throw retryError;
    }
  }
};

const releaseShiftLock = async (lockId) => {
  if (!lockId) {
    return;
  }

  try {
    await ShiftAssignmentLock.findByIdAndDelete(lockId);
  } catch (_error) {
    // Lock cleanup is best-effort because TTL handles stale rows.
  }
};

const getShifts = asyncHandler(async (req, res) => {
  const cacheKey = buildRequestCacheKey("shifts", req);
  const cachedPayload = getCachedPayload(cacheKey);

  if (cachedPayload) {
    return res.json(cachedPayload);
  }

  const { page, limit, skip } = getPagination(req.query);
  const filters = {};

  if (req.query.employee_id) {
    filters.employee = req.query.employee_id;
  }

  if (req.query.status) {
    filters.status = req.query.status;
  }

  if (req.query.branch) {
    filters.branch = req.query.branch;
  }

  if (req.query.shift_date) {
    filters.shiftDateKey = req.query.shift_date;
  }

  if (req.query.start_date || req.query.end_date) {
    filters.shiftDate = {};

    if (req.query.start_date) {
      filters.shiftDate.$gte = normalizeDateInput(req.query.start_date, "start_date").date;
    }

    if (req.query.end_date) {
      filters.shiftDate.$lte = normalizeDateInput(req.query.end_date, "end_date").date;
    }
  }

  if (req.user.role === "employee") {
    const requesterEmployeeId = getRequesterEmployeeId(req);

    if (!requesterEmployeeId) {
      throw new AppError("Employee profile is not linked to this user.", 400);
    }

    filters.employee = requesterEmployeeId;
  }

  if (req.user.role === "manager") {
    const managedIds = await getManagerEmployeeIds(req);
    filters.employee = req.query.employee_id || { $in: managedIds };

    if (req.query.employee_id && !managedIds.includes(String(req.query.employee_id))) {
      filters.employee = null;
    }
  }

  const [shifts, total] = await Promise.all([
    Shift.find(filters)
      .populate("employee", "name email department branch designation status manager")
      .sort({ shiftDate: 1, startMinutes: 1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    Shift.countDocuments(filters),
  ]);

  const payload = {
    success: true,
    data: shifts,
    pagination: buildPaginationMeta({ total, page, limit }),
  };

  setCachedPayload(cacheKey, payload);

  res.json(payload);
});

const createShift = asyncHandler(async (req, res) => {
  const employeeId = req.body.employee_id || req.body.employeeId;
  const shiftDate = normalizeDateInput(req.body.shift_date || req.body.shiftDate, "shift_date");
  const { startMinutes, endMinutes } = getShiftWindow(req.body.start_time, req.body.end_time);
  const branch = String(req.body.branch || "").trim();
  const status = req.body.status ? String(req.body.status).toLowerCase() : "assigned";

  if (!employeeId) {
    throw new AppError("employee_id is required.", 400);
  }

  if (!branch) {
    throw new AppError("branch is required.", 400);
  }

  if (!["assigned", "completed", "cancelled"].includes(status)) {
    throw new AppError("Invalid shift status.", 400);
  }

  await assertManagerCanAssign(req, employeeId);
  const employee = await ensureEmployeeCanBeAssigned(employeeId);
  const shiftLock = await acquireShiftLock(employee._id, shiftDate.key);

  let shift;

  try {
    await ensureNoApprovedLeaveConflict(employee._id, shiftDate.date);
    await ensureNoOverlap({
      employeeId: employee._id,
      shiftDateKey: shiftDate.key,
      startMinutes,
      endMinutes,
    });

    shift = await Shift.create({
      employee: employee._id,
      shiftDate: shiftDate.date,
      shiftDateKey: shiftDate.key,
      startTime: req.body.start_time,
      endTime: req.body.end_time,
      startMinutes,
      endMinutes,
      branch,
      status,
      createdBy: req.user._id,
      updatedBy: req.user._id,
    });
  } catch (error) {
    if (error.code === 11000) {
      throw new AppError("Duplicate shift assignment detected.", 409);
    }

    throw error;
  } finally {
    await releaseShiftLock(shiftLock?._id);
  }

  const createdShift = await Shift.findById(shift._id).populate(
    "employee",
    "name email department branch designation status manager"
  );

  await createAuditLog(req, {
    action: "shift.create",
    entityType: "Shift",
    entityId: shift._id,
    metadata: { employeeId, shiftDate: shiftDate.key },
  });

  invalidateCacheNamespace("shifts");

  res.status(201).json({
    success: true,
    message: "Shift assigned successfully.",
    data: createdShift,
  });
});

const updateShift = asyncHandler(async (req, res) => {
  const shift = await Shift.findById(req.params.id);

  if (!shift) {
    throw new AppError("Shift not found.", 404);
  }

  const employeeId = req.body.employee_id || req.body.employeeId || shift.employee;

  await assertManagerCanAssign(req, employeeId);
  await ensureEmployeeCanBeAssigned(employeeId);

  const shiftDate =
    req.body.shift_date !== undefined || req.body.shiftDate !== undefined
      ? normalizeDateInput(req.body.shift_date || req.body.shiftDate, "shift_date")
      : { date: shift.shiftDate, key: shift.shiftDateKey };

  const nextStartTime = req.body.start_time || shift.startTime;
  const nextEndTime = req.body.end_time || shift.endTime;
  const { startMinutes, endMinutes } = getShiftWindow(nextStartTime, nextEndTime);
  const nextStatus = req.body.status ? String(req.body.status).toLowerCase() : shift.status;
  const nextBranch = req.body.branch ? String(req.body.branch).trim() : shift.branch;

  if (!["assigned", "completed", "cancelled"].includes(nextStatus)) {
    throw new AppError("Invalid shift status.", 400);
  }

  if (!nextBranch) {
    throw new AppError("branch is required.", 400);
  }

  const shiftLock = await acquireShiftLock(employeeId, shiftDate.key);

  try {
    if (nextStatus !== "cancelled") {
      await ensureNoApprovedLeaveConflict(employeeId, shiftDate.date);
      await ensureNoOverlap({
        employeeId,
        shiftDateKey: shiftDate.key,
        startMinutes,
        endMinutes,
        excludeId: shift._id,
      });
    }

    shift.employee = employeeId;
    shift.shiftDate = shiftDate.date;
    shift.shiftDateKey = shiftDate.key;
    shift.startTime = nextStartTime;
    shift.endTime = nextEndTime;
    shift.startMinutes = startMinutes;
    shift.endMinutes = endMinutes;
    shift.branch = nextBranch;
    shift.status = nextStatus;
    shift.updatedBy = req.user._id;

    await shift.save();
  } catch (error) {
    if (error.code === 11000) {
      throw new AppError("Duplicate shift assignment detected.", 409);
    }

    throw error;
  } finally {
    await releaseShiftLock(shiftLock?._id);
  }

  const updatedShift = await Shift.findById(shift._id).populate(
    "employee",
    "name email department branch designation status manager"
  );

  await createAuditLog(req, {
    action: "shift.update",
    entityType: "Shift",
    entityId: shift._id,
    metadata: { employeeId: String(employeeId), status: nextStatus },
  });

  invalidateCacheNamespace("shifts");

  res.json({
    success: true,
    message: "Shift updated successfully.",
    data: updatedShift,
  });
});

const deleteShift = asyncHandler(async (req, res) => {
  const shift = await Shift.findById(req.params.id);

  if (!shift) {
    throw new AppError("Shift not found.", 404);
  }

  await assertManagerCanAssign(req, shift.employee);

  const attendance = await Attendance.findOne({ shift: shift._id });

  if (attendance) {
    throw new AppError("Shift cannot be deleted because attendance already exists.", 409);
  }

  await Shift.findByIdAndDelete(shift._id);

  await createAuditLog(req, {
    action: "shift.delete",
    entityType: "Shift",
    entityId: shift._id,
    metadata: { employeeId: String(shift.employee) },
  });

  invalidateCacheNamespace("shifts");

  res.json({
    success: true,
    message: "Shift deleted successfully.",
  });
});

module.exports = {
  createShift,
  deleteShift,
  getShifts,
  updateShift,
};
