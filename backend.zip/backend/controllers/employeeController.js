const Attendance = require("../models/Attendance");
const Employee = require("../models/Employee");
const Leave = require("../models/Leave");
const Shift = require("../models/Shift");
const User = require("../models/User");
const createAuditLog = require("../utils/auditLogger");
const AppError = require("../utils/AppError");
const asyncHandler = require("../utils/asyncHandler");
const {
  buildRequestCacheKey,
  getCachedPayload,
  invalidateCacheNamespace,
  setCachedPayload,
} = require("../utils/cacheStore");
const { normalizeDateInput } = require("../utils/dateTime");
const { buildPaginationMeta, buildSearchFilter, getPagination } = require("../utils/queryFeatures");
const { normalizeEmail, optionalString, requiredString } = require("../utils/validation");

const ALLOWED_ROLES = ["admin", "manager", "employee"];

const getRequesterEmployeeId = (req) =>
  String(req.user.employee?._id || req.user.employee || "");

const ensureManagerScope = (req, employee) => {
  if (req.user.role !== "manager") {
    return;
  }

  const requesterEmployeeId = getRequesterEmployeeId(req);

  if (!requesterEmployeeId) {
    throw new AppError("Manager profile is not linked to an employee record.", 403);
  }

  if (String(employee.manager || "") !== requesterEmployeeId) {
    throw new AppError("Managers can only manage their direct reports.", 403);
  }
};

const ensureEmailAvailable = async (email, employeeId = null, userId = null) => {
  const employeeMatch = await Employee.findOne({
    email,
    ...(employeeId ? { _id: { $ne: employeeId } } : {}),
  });

  if (employeeMatch) {
    throw new AppError("An employee with this email already exists.", 409);
  }

  const userMatch = await User.findOne({
    email,
    ...(userId ? { _id: { $ne: userId } } : {}),
  });

  if (userMatch) {
    throw new AppError("A user with this email already exists.", 409);
  }
};

const normalizeStatus = (value) => {
  if (value === undefined) {
    return undefined;
  }

  const status = String(value).toLowerCase();

  if (!["active", "inactive"].includes(status)) {
    throw new AppError("Status must be active or inactive.", 400);
  }

  return status;
};

const normalizeRole = (value, currentRole = "employee") => {
  if (value === undefined) {
    return currentRole;
  }

  const role = String(value).toLowerCase();

  if (!ALLOWED_ROLES.includes(role)) {
    throw new AppError("Invalid role.", 400);
  }

  return role;
};

const getEmployees = asyncHandler(async (req, res) => {
  const cacheKey = buildRequestCacheKey("employees", req);
  const cachedPayload = getCachedPayload(cacheKey);

  if (cachedPayload) {
    return res.json(cachedPayload);
  }

  const { page, limit, skip } = getPagination(req.query);

  const filters = {
    ...buildSearchFilter(req.query.search, [
      "name",
      "email",
      "department",
      "branch",
      "designation",
    ]),
  };

  if (req.query.department) {
    filters.department = req.query.department;
  }

  if (req.query.branch) {
    filters.branch = req.query.branch;
  }

  if (req.query.status) {
    filters.status = req.query.status;
  }

  if (req.query.manager_id) {
    filters.manager = req.query.manager_id;
  }

  if (req.user.role === "manager") {
    filters.manager = getRequesterEmployeeId(req);
  }

  const [employees, total] = await Promise.all([
    Employee.find(filters)
      .populate("manager", "name email designation branch")
      .populate("user", "role isActive")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    Employee.countDocuments(filters),
  ]);

  const payload = {
    success: true,
    data: employees,
    pagination: buildPaginationMeta({ total, page, limit }),
  };

  setCachedPayload(cacheKey, payload);

  res.json(payload);
});

const createEmployee = asyncHandler(async (req, res) => {
  const name = requiredString(req.body.name, "name");
  const email = normalizeEmail(req.body.email);
  const department = requiredString(req.body.department, "department");
  const branch = requiredString(req.body.branch, "branch");
  const designation = requiredString(req.body.designation, "designation");
  const joiningDate = normalizeDateInput(
    req.body.joining_date || req.body.joiningDate,
    "joining_date"
  ).date;
  const status = normalizeStatus(req.body.status) || "active";
  const password = optionalString(req.body.password);
  const wantsLoginAccount =
    req.body.create_login_account === true ||
    req.body.createLoginAccount === true ||
    Boolean(password);

  if (wantsLoginAccount && password.length < 6) {
    throw new AppError("Password must be at least 6 characters long.", 400);
  }

  const requestedRole = normalizeRole(req.body.role, "employee");

  if (req.user.role !== "admin" && requestedRole !== "employee") {
    throw new AppError("Only admins can create manager or admin accounts.", 403);
  }

  let managerId = req.body.manager_id || req.body.managerId || null;

  if (req.user.role === "manager") {
    managerId = getRequesterEmployeeId(req);
  }

  if (managerId) {
    const manager = await Employee.findById(managerId);

    if (!manager) {
      throw new AppError("Manager not found.", 404);
    }
  }

  await ensureEmailAvailable(email);

  const employee = await Employee.create({
    name,
    email,
    department,
    branch,
    designation,
    joiningDate,
    status,
    manager: managerId,
    createdBy: req.user._id,
  });

  let user = null;

  if (wantsLoginAccount) {
    try {
      user = await User.create({
        name,
        email,
        password,
        role: requestedRole,
        employee: employee._id,
        isActive: status === "active",
      });
    } catch (error) {
      await Employee.findByIdAndDelete(employee._id);
      throw error;
    }

    employee.user = user._id;
    await employee.save();
  }

  const createdEmployee = await Employee.findById(employee._id)
    .populate("manager", "name email designation branch")
    .populate("user", "role isActive");

  await createAuditLog(req, {
    action: "employee.create",
    entityType: "Employee",
    entityId: employee._id,
    metadata: { hasLoginAccount: Boolean(user) },
  });

  invalidateCacheNamespace("employees");
  invalidateCacheNamespace("shifts");
  invalidateCacheNamespace("leaves");

  res.status(201).json({
    success: true,
    message: "Employee created successfully.",
    data: createdEmployee,
  });
});

const updateEmployee = asyncHandler(async (req, res) => {
  const employee = await Employee.findById(req.params.id).populate("user");

  if (!employee) {
    throw new AppError("Employee not found.", 404);
  }

  ensureManagerScope(req, employee);

  const nextName = req.body.name !== undefined ? requiredString(req.body.name, "name") : employee.name;
  const nextEmail =
    req.body.email !== undefined ? normalizeEmail(req.body.email) : employee.email;
  const nextDepartment =
    req.body.department !== undefined
      ? requiredString(req.body.department, "department")
      : employee.department;
  const nextBranch =
    req.body.branch !== undefined ? requiredString(req.body.branch, "branch") : employee.branch;
  const nextDesignation =
    req.body.designation !== undefined
      ? requiredString(req.body.designation, "designation")
      : employee.designation;
  const nextJoiningDate =
    req.body.joining_date !== undefined || req.body.joiningDate !== undefined
      ? normalizeDateInput(
          req.body.joining_date || req.body.joiningDate,
          "joining_date"
        ).date
      : employee.joiningDate;
  const nextStatus = normalizeStatus(req.body.status) || employee.status;
  const password = optionalString(req.body.password);
  const wantsLoginAccount =
    req.body.create_login_account === true ||
    req.body.createLoginAccount === true ||
    Boolean(password);

  if (password && password.length < 6) {
    throw new AppError("Password must be at least 6 characters long.", 400);
  }

  let nextRole = employee.user?.role || "employee";

  if (req.body.role !== undefined) {
    nextRole = normalizeRole(req.body.role, nextRole);

    if (req.user.role !== "admin" && nextRole !== "employee") {
      throw new AppError("Only admins can assign manager or admin roles.", 403);
    }
  }

  let managerId =
    req.body.manager_id !== undefined || req.body.managerId !== undefined
      ? req.body.manager_id || req.body.managerId || null
      : employee.manager;

  if (req.user.role === "manager") {
    managerId = getRequesterEmployeeId(req);
  }

  if (managerId && String(managerId) === String(employee._id)) {
    throw new AppError("An employee cannot be their own manager.", 400);
  }

  if (managerId) {
    const manager = await Employee.findById(managerId);

    if (!manager) {
      throw new AppError("Manager not found.", 404);
    }
  }

  await ensureEmailAvailable(nextEmail, employee._id, employee.user?._id || null);

  employee.name = nextName;
  employee.email = nextEmail;
  employee.department = nextDepartment;
  employee.branch = nextBranch;
  employee.designation = nextDesignation;
  employee.joiningDate = nextJoiningDate;
  employee.status = nextStatus;
  employee.manager = managerId;
  await employee.save();

  if (employee.user) {
    employee.user.name = nextName;
    employee.user.email = nextEmail;
    employee.user.isActive = nextStatus === "active";
    employee.user.role = nextRole;

    if (password) {
      employee.user.password = password;
    }

    await employee.user.save();
  } else if (wantsLoginAccount) {
    const createdUser = await User.create({
      name: nextName,
      email: nextEmail,
      password,
      role: nextRole,
      employee: employee._id,
      isActive: nextStatus === "active",
    });

    employee.user = createdUser._id;
    await employee.save();
  }

  const updatedEmployee = await Employee.findById(employee._id)
    .populate("manager", "name email designation branch")
    .populate("user", "role isActive");

  await createAuditLog(req, {
    action: "employee.update",
    entityType: "Employee",
    entityId: employee._id,
    metadata: { status: nextStatus },
  });

  invalidateCacheNamespace("employees");
  invalidateCacheNamespace("shifts");
  invalidateCacheNamespace("leaves");

  res.json({
    success: true,
    message: "Employee updated successfully.",
    data: updatedEmployee,
  });
});

const deleteEmployee = asyncHandler(async (req, res) => {
  const employee = await Employee.findById(req.params.id);

  if (!employee) {
    throw new AppError("Employee not found.", 404);
  }

  const [shiftCount, attendanceCount, leaveCount] = await Promise.all([
    Shift.countDocuments({ employee: employee._id }),
    Attendance.countDocuments({ employee: employee._id }),
    Leave.countDocuments({ employee: employee._id }),
  ]);

  if (shiftCount || attendanceCount || leaveCount) {
    throw new AppError(
      "Employee cannot be deleted because related shifts, attendance, or leave records exist.",
      409
    );
  }

  if (employee.user) {
    await User.findByIdAndDelete(employee.user);
  }

  await Employee.findByIdAndDelete(employee._id);

  await createAuditLog(req, {
    action: "employee.delete",
    entityType: "Employee",
    entityId: employee._id,
    metadata: { email: employee.email },
  });

  invalidateCacheNamespace("employees");
  invalidateCacheNamespace("shifts");
  invalidateCacheNamespace("leaves");

  res.json({
    success: true,
    message: "Employee deleted successfully.",
  });
});

module.exports = {
  createEmployee,
  deleteEmployee,
  getEmployees,
  updateEmployee,
};
